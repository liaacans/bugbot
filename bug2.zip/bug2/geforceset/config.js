/*

 * Base By Rekenz
 * Jangan hapus credit ya anjing

 Contact Support:
 📞 Whatsapp : wa.me/628978575652
 ☎ Telegram : t.me/Rekenzx
 
*/

global.owner = [
  "628978575652", //ganti nomor owner
  "628978575652" //nomor owner kedua kalo ada
]

global.namaowner = '𝐑𝐞𝐤𝐞𝐧𝐳'
global.idsaluran = '120363399106257546@newsletter'
global.linkgc = '-'

let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})
