const fs = require('fs')

global.owner = "62895323931022" //owner number
global.footer = "pfft" //footer section
global.status = true //"self/public" section of the bot
global.andrazyy = "↯" // global simbol 🗿
global.teks = "❀ ✰ 𝐈𝐍𝐌𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ✰ ❀"
global.versi = "1.0.0"
global.gen = "5 New Era"
global.cici = "MIKU DEV"
global.lol = "";
global.mess = {
    owner: "lu bukan owner pantek"}
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
